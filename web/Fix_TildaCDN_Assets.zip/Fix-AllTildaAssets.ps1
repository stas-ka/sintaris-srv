
# === Настройки ===
$RootDir = "happytram_full_pages"
$AssetDir = "$RootDir\assets"
mkdir $AssetDir -Force | Out-Null

# Расширения файлов, которые проверяем
$FileTypes = "*.html", "*.css", "*.js"

# Шаблон для ссылок на static.tildacdn.com
$pattern = 'https://static\.tildacdn\.com/[\w\-/]+\.(png|jpg|jpeg|gif|svg|webp|css|js|woff2?)'

# === Обход всех файлов ===
foreach ($ext in $FileTypes) {
    Get-ChildItem -Path $RootDir -Recurse -Include $ext | ForEach-Object {
        $file = $_.FullName
        $content = Get-Content $file -Raw
        $originalContent = $content
        $matches = Select-String -InputObject $content -Pattern $pattern -AllMatches

        foreach ($match in $matches.Matches) {
            $url = $match.Value
            $filename = Split-Path $url -Leaf
            $localPath = Join-Path $AssetDir $filename

            if (!(Test-Path $localPath)) {
                try {
                    Invoke-WebRequest -Uri $url -OutFile $localPath -UseBasicParsing
                    Write-Host "📥 Скачано: $filename"
                } catch {
                    Write-Warning "⚠️ Не удалось скачать: $url"
                }
            }

            $escapedUrl = [Regex]::Escape($url)
            $content = $content -replace $escapedUrl, "assets/$filename"
        }

        # Обновим файл, если были изменения
        if ($content -ne $originalContent) {
            Copy-Item $file "$file.bak" -Force
            Set-Content -Path $file -Value $content -Encoding UTF8
            Write-Host "✅ Обновлён: $file"
        }
    }
}

Write-Host "`n🎯 Готово! Все ресурсы с tildacdn теперь локальные, ссылки заменены."
